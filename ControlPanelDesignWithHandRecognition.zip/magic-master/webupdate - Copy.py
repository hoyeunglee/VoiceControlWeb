import asyncio
import datetime
import random
import websockets
from subprocess32 import STDOUT, check_output
import re
import sys
import traceback
import paramiko
from netmiko import ConnectHandler
import pyttsx3
import speech_recognition as sr
import os
import subprocess
from os import listdir
from os.path import isfile, join
currentdirectory = os.getcwd()
from gensim.test.utils import common_texts
from gensim.models import Word2Vec
import gensim.downloader as api

model = Word2Vec(common_texts, size=100, window=5, min_count=1, workers=4)
word_vectors = model.wv

#word_vectors = api.load("glove-wiki-gigaword-100")

complain = ["enlarge","next"]
controls1 = ["enlarge","next"]

r = sr.Recognizer()
mic = sr.Microphone()
proc = subprocess.Popen('cmd.exe', stdin = subprocess.PIPE, stdout = subprocess.PIPE)
engine = pyttsx3.init()

officefiles = [f for f in listdir(os.path.join("C:\Program Files (x86)\Microsoft Office\Office16","")) if isfile(os.path.join("C:\Program Files (x86)\Microsoft Office\Office16", "Excel.exe"))]

result = ""
r.dynamic_energy_threshold = False
r.energy_threshold = 400
engine.setProperty('voice', "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_EN-US_DAVID_11.0")

onceerror = 0
currentwindow = 0
controlresult = 0
doneit = 0
async def time(websocket, path):
    while True:
        try:
            with mic as source:
                onceerror = 0
                r.adjust_for_ambient_noise(source, duration=3)
                print("Hello. Please speak")
                engine.say('Hello. Please speak')
                engine.runAndWait()
                audio = r.listen(source)
                result = r.recognize_google(audio, show_all=True)
                print(result["alternative"])
                lengthofcomplain = 7
                doneit = 0
                for mess in result["alternative"]:
                    for complain1 in complain:
                        for startcomplain in range(0,mess["transcript"].__len__()):
                            complain2 = mess["transcript"][startcomplain:startcomplain+lengthofcomplain]
                            print("complain1="+complain1)
                            print("complain2="+complain2)
                            similarity = word_vectors.wmdistance(complain1.lower(),complain2.lower())
                            print(complain1)
                            print(complain2)
                            print(similarity)
                            if similarity < 3.1 and doneit == 0:
                                try:
                                    if complain1.lower() in ["next"] or complain2.lower().startswith("s") or complain2.lower().startswith("x") or complain2.lower().startswith("ex") or complain2.lower().startswith("le"):
                                           controlresult = currentwindow
                                           currentwindow = currentwindow + 1
                                           if currentwindow == 3:
                                               currentwindow = 0
                                           controlresult = currentwindow   
                                           await websocket.send(str(controlresult))
                                           await asyncio.sleep(random.random() * 3)
                                           doneit = 1
                                    elif complain1.lower() in ["enlarge"] or complain2.lower().startswith("en") or complain2.lower().startswith("an"):
                                           await websocket.send(str("100"))
                                           await asyncio.sleep(random.random() * 3)
                                           doneit = 1
                                    elif (complain1.upper()+".EXE") in officefiles:
                                        stdout, stderr = subprocess.Popen(os.path.join("C:\Program Files (x86)\Microsoft Office\Office16", "EXCEL.EXE"))
                                        stdout
                                    else:
                                        stdout, stderr = subprocess.Popen(complain1.lower()+".exe")
                                        stdout
                                except:
                                    print("can not open")
        except Exception as e: 
            if onceerror == 0:
                print(e)
                print("try again")
                onceerror = 1
        
start_server = websockets.serve(time, '127.0.0.1', 5678)

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()